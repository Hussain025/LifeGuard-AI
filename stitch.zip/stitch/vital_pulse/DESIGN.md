# Design System Specification: Medical-Tech Precision

## 1. Overview & Creative North Star: "The Clinical Guardian"
This design system moves beyond the cold, sterile feel of traditional medical software. Our Creative North Star is **"The Clinical Guardian"**—an interface that balances the urgent authority of emergency medicine with the calming, sophisticated breathability of high-end editorial design.

We reject the "template" look of rigid grids and 1px borders. Instead, we use **Intentional Asymmetry** and **Tonal Layering** to guide the eye. By utilizing oversized typography and "glass-on-glass" depth, we create a UI that feels both physically present and digitally intelligent. This system is designed to be operated under stress; clarity is our primary aesthetic.

---

## 2. Color Theory & Surface Logic
The palette is rooted in medical trust but elevated through high-contrast depth. We strictly follow a **No-Line Rule**: boundaries are defined by tonal shifts and background changes, never by 1px solid strokes.

### Color Tokens
*   **Primary Action:** `primary` (#00658d) & `primary_container` (#00aeef). Use the container token for high-visibility buttons.
*   **Emergency/SOS:** `tertiary` (#bb171c) & `on_tertiary_container` (#790009). These provide the necessary psychological urgency.
*   **Backgrounds:** `surface` (#f3faff) provides a crisp, clinical base.

### The Glass & Gradient Rule
To avoid a flat "Bootstrap" appearance, use **Signature Textures**:
*   **Hero Elements:** Apply a subtle linear gradient from `primary` to `primary_container` at 135°.
*   **Glassmorphism:** For floating emergency overlays, use `surface_container_low` at 80% opacity with a `24px` backdrop blur. This allows the background life-signals to bleed through, maintaining context during crises.

### Surface Hierarchy (Nesting)
Treat the UI as a series of stacked sheets of medical-grade frosted glass:
1.  **Level 0 (Base):** `surface` (#f3faff)
2.  **Level 1 (Sections):** `surface_container_low` (#e6f6ff)
3.  **Level 2 (Interactive Cards):** `surface_container_lowest` (#ffffff)
*Note: Use background shifts to define importance. A white card on a light blue-tinted section creates a natural lift without visual clutter.*

---

## 3. Typography: The Editorial Authority
We utilize two typefaces to distinguish between **Data (Inter)** and **Direction (Manrope)**.

*   **The Hero Scale (Manrope):** `display-lg` (3.5rem) and `headline-lg` (2rem) are used for critical status updates (e.g., "AI Analyzing Heart Rate"). These large sizes ensure accessibility during high-stress movement.
*   **The Utility Scale (Inter):** `body-md` (0.875rem) and `label-md` (0.75rem) handle technical medical data and secondary metadata.

**Hierarchy Strategy:** Bold, oversized headlines provide the "At-a-Glance" information, while smaller, high-contrast Inter text provides the "Deep Dive" details. This creates an editorial rhythm that prevents the screen from feeling crowded.

---

## 4. Elevation & Depth: Tonal Layering
We move away from traditional drop shadows in favor of **Ambient Luminosity**.

*   **The Layering Principle:** Instead of a shadow, place a `surface_container_highest` element inside a `surface_container_low` area to create "indented" or "raised" sections.
*   **Ambient Shadows:** For floating SOS buttons, use the `on_surface` color at 6% opacity with a `32px` blur and a `12px` Y-offset. This mimics natural light reflecting off medical equipment.
*   **The Ghost Border:** If a boundary is required for accessibility, use `outline_variant` at 15% opacity. **Never use 100% opaque borders.**

---

## 5. Components: Style & Execution

### Prominent Buttons (The SOS & Primary)
*   **Primary:** Background: `primary_container`. Shape: `xl` (3rem). Padding: `2rem` horizontal.
*   **SOS Variant:** Background: `tertiary`. Text: `on_tertiary`. Include a subtle "Pulse" animation using a `tertiary_container` outer ring that expands and fades.
*   **Interaction:** On press, scale the button down to 96% to provide tactile physical feedback.

### Status Cards & Pulse Indicators
*   **Forbid Dividers:** Do not use lines to separate medical history or vitals. Use `1.4rem` (`4`) vertical spacing or a shift to `surface_container_low`.
*   **Pulse Indicators:** Use a `12px` dot using the `primary_fixed` color with a continuous CSS scale animation (1.0 to 1.5) at 60bpm to signify "Live AI Monitoring."

### Input Fields & Controls
*   **Inputs:** Use `surface_container_highest` with a `md` (1.5rem) corner radius. Label must be `label-md` in `on_surface_variant`.
*   **Checkboxes/Radios:** Use `full` (9999px) rounding. When active, use a glow effect using `primary_container` at 30% opacity rather than a thick border.

### Bottom Navigation
*   **Style:** A "Floating Island" design. Use a `surface_container_lowest` container with `xl` (3rem) rounding, suspended `1.7rem` (`5`) from the bottom edge. Use a `24px` backdrop blur for the island background.

---

## 6. Do’s and Don'ts

### Do:
*   **Do** use extreme whitespace. Use spacing token `10` (3.5rem) between major functional groups to prevent "panic-clicking."
*   **Do** use `manrope` for numbers. Medical vitals (BPM, SpO2) should be displayed in `headline-lg` for maximum legibility.
*   **Do** use asymmetrical layouts. A left-aligned headline with a right-aligned "Glass" card creates a premium, custom feel.

### Don't:
*   **Don't** use 1px dividers. It makes the app look like a legacy hospital database.
*   **Don't** use pure black (#000000). Use `on_background` (#071e27) for high-contrast text that feels sophisticated, not jarring.
*   **Don't** use standard `0.25rem` corners. Everything must feel soft and human; stick to `1rem` (16px) or higher.